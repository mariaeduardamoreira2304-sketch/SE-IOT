int led_red = 13;
int led_blue = 12;

int btn_red = 11;
int btn_blue = 10;

int btn_state_red = 0;
int btn_state_blue = 0;

void setup() {
  // put your setup code here, to run once:
  pinMode(led_red, OUTPUT);
  pinMode(led_blue, OUTPUT);
  pinMode(btn_red, INPUT);
  pinMode(btn_blue, INPUT);

}

void loop() {
  // put your main code here, to run repeatedly:
  btn_state_red = digitalRead(btn_red);
  btn_state_blue = digitalRead(btn_blue);

  if (btn_state_red == HIGH){
    digitalWrite(led_red, HIGH);
  }
  else{
    digitalWrite(led_red, LOW);
  }

   if (btn_state_blue == HIGH){
    digitalWrite(led_blue, HIGH);
  }
  else{
    digitalWrite(led_blue, LOW);
  }

}



