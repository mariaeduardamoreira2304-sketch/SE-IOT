int ledr = 8;
int ledy = 9;
int ledg = 10;

void setup() {
  Serial.begin(9600);

  pinMode(ledr, OUTPUT);
  pinMode(ledy, OUTPUT);
  pinMode(ledg, OUTPUT);
}

void loop() {

  // Vermelho
  digitalWrite(ledr, HIGH);
  digitalWrite(ledy, LOW);
  digitalWrite(ledg, LOW);
  Serial.println("Vermelho");
  delay(3000);

  // Amarelo
  digitalWrite(ledr, LOW);
  digitalWrite(ledy, HIGH);
  digitalWrite(ledg, LOW);
  Serial.println("Amarelo");
  delay(3000);

  // Verde
  digitalWrite(ledr, LOW);
  digitalWrite(ledy, LOW);
  digitalWrite(ledg, HIGH);
  Serial.println("Verde");
  delay(3000);
}