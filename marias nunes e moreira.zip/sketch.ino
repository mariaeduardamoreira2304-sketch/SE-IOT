void setup() {
  Serial.begin(9600);

  String nome = "Arduino";

  // FUNÇÕES DE TEXTO

  Serial.println(nome.length());

  Serial.println(nome.charAt(0));

  Serial.println(nome.substring(0, 3));

  Serial.println(nome.indexOf("u"));

  Serial.println(nome.lastIndexOf("o"));

  nome.toUpperCase();
  Serial.println(nome);

  nome.toLowerCase();
  Serial.println(nome);

  nome.replace("Arduino", "ESP32");
  Serial.println(nome);

  nome.concat(" UNO");
  Serial.println(nome);

  Serial.println(nome.startsWith("ESP32"));

  Serial.println(nome.endsWith("UNO"));


  // COMPARAÇÃO

  String a = "Arduino";
  String b = "arduino";

  Serial.println(a.equals(b));

  Serial.println(a.equalsIgnoreCase(b));


  // TRIM

  String texto = "   Arduino   ";

  texto.trim();

  Serial.println(texto);


  // FUNÇÕES MATEMÁTICAS

  Serial.println(abs(-10));

  int valor = 150;

  valor = constrain(valor, 0, 100);

  Serial.println(valor);

  Serial.println(map(50, 0, 100, 0, 255));

  Serial.println(max(10, 20));

  Serial.println(min(10, 20));

  Serial.println(pow(2, 3));

  Serial.println(sqrt(25));

  Serial.println(5 * 5);
}
